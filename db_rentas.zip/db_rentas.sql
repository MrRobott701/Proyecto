/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `db_rentas` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_rentas`;

CREATE TABLE IF NOT EXISTS `cobros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_contrato` int NOT NULL DEFAULT '0',
  `saldo` float NOT NULL DEFAULT '0',
  `renta` float NOT NULL DEFAULT '0',
  `fecha_pago` datetime NOT NULL,
  `adeudo` float DEFAULT '0',
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cobros de renta';


CREATE TABLE IF NOT EXISTS `conductores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `direccion` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `telefono` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `nombreDocumento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `nroDocumento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `ineDoc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `licenciaDoc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `reciboLuz` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `reciboAgua` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalNombre` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalTelefono` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalDoc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalLuz` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalAgua` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `nota` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `activo` int DEFAULT '0',
  `idVehiculo` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Conductores';

INSERT INTO `conductores` (`id`, `nombre`, `direccion`, `telefono`, `nombreDocumento`, `nroDocumento`, `ineDoc`, `licenciaDoc`, `reciboLuz`, `reciboAgua`, `avalNombre`, `avalTelefono`, `avalDoc`, `avalLuz`, `avalAgua`, `nota`, `activo`, `idVehiculo`) VALUES
	(57, 'Jorge Ivan Perez Hernandez', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'ELVIA', '648-572-25', '', '', '', '', 0, 0),
	(58, 'Hotel Costa Ensenada', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', 'https://drive.google.com/file/d/1aNaZjELDxA-7R8rpTASGrrHp12i1nmxp/view?usp=drivesdk', 'https://drive.google.com/file/d/1jQtm7K2MKYJVYE2XQuAiksctqX2eFP6w/view?usp=drivesdk', 'https://drive.google.com/file/d/1YqWE0WhEN7fjuehphpAQqHsK4Ark1zob/view?usp=drivesdk', 'https://drive.google.com/file/d/1OqdefyXLL8q61PXOWf3klwZl54C4Tyrb/view?usp=drivesdk', 'Elvia Oralia Hernandez', '', '', '', '', '', 1, 62),
	(59, 'Joaquin Guzman Loera', 'Todos Santos, San Carlos, #137, CP-22785, Ensenada Baja California', '3456754324', 'CURP', 'ASDFG43EYGUDHBC8', 'https://drive.google.com/file/d/1l0SyIs_aSPyzbIrmC53sb0ObsjWAywpu/view?usp=drivesdk', 'https://drive.google.com/file/d/1WIEx0q1iITwaUA3i4oNGQkRum4QZ2jPM/view?usp=drivesdk', 'https://drive.google.com/file/d/1inXm3x0DSJP4Hm-wDu117cdJiYAp8O4g/view?usp=drivesdk', '', 'Elvia Oralia Hernandez', '', '', '', '', '', 0, NULL),
	(60, 'Joaquin Guzman Loera', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'Elvia Oralia Hernandez', '', '', '', '', '', 1, 63),
	(61, 'Hotel Costa Ensenada', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'Elvia Oralia Hernandez', '6485722526', '', '', '', '', 0, NULL),
	(62, 'Hotel Costa Ensenada', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'Elvia Oralia Hernandez', '6485722526', 'https://drive.google.com/file/d/1BxJC4Xdp-IDM6HDYqPpQ3AfxgwL440Qp/view?usp=drivesdk', '', '', '', 1, 69),
	(63, 'Hotel Costa Ensenada', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'Elvia Oralia Hernandez', '6485722526', 'https://drive.google.com/file/d/1PZBoGhXA7v6-FR3xNzweA3O4ahUOxhid/view?usp=drivesdk', 'https://drive.google.com/file/d/1FIQMem6sU5VVZkJk9_18sCOc9Duu1I8D/view?usp=drivesdk', '', '', 0, NULL),
	(64, 'Hotel Costa Ensenada', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'Elvia Oralia Hernandez', '6485722526', 'https://drive.google.com/file/d/1yy0R3K5TR3LEiMcpneBy397m0U6nfj2L/view?usp=drivesdk', 'https://drive.google.com/file/d/1dtr1Zls2hYnq93ZGTx6BI65OIOIU6vGn/view?usp=drivesdk', 'https://drive.google.com/file/d/1A-BLXrRYk2p5pc-KS0ijJJn2II4JxeP1/view?usp=drivesdk', '', 1, 67),
	(65, 'Edgar Javier Moralez Rodriguez', 'Todos Santos, San Carlos, #137, Casa Azul con Rejas Negras, CP-22785, Ensenada Baja California', '8785452636', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', 'Elvia Oralia Hernandez', '6485722526', '', '', '', 'Casa Dos Pisos', 0, NULL),
	(67, 'Joaquin Guzman Loera', 'Todos Santos, San Carlos, CP-22785, Ensenada Baja California', '3456754324', 'INE', 'ASDFG43EYGUDHBC8', 'https://drive.google.com/file/d/1Ea70Nd3pf4I5W6U8VlJX1_TznqJ9Ha8Z/view?usp=drivesdk', 'https://drive.google.com/file/d/1cxp4QBb2Gz1KAYte4o5QTex9Nm1VddUT/view?usp=drivesdk', 'https://drive.google.com/file/d/1Go3MU5hSzRZq7X8sUOOCT_2HlHeZ9wyr/view?usp=drivesdk', 'https://drive.google.com/file/d/12y1AaupzJK077EtFepX0Q5ZlrrZWVtkG/view?usp=drivesdk', 'Manuel Torres felix', '6485722526', 'https://drive.google.com/file/d/19SnToFAofBEmmITI39Ly8pCf4VonP1_V/view?usp=drivesdk', 'https://drive.google.com/file/d/1mMpvDKaAsYahEzHqD9Eh7wavezrIRYxK/view?usp=drivesdk', 'https://drive.google.com/file/d/1O10BGpPp4zjVLTawFZC7qkQbwuYNrdgY/view?usp=drivesdk', 'Casa Dos Pisos', 1, 68),
	(69, 'AESRDTYUHJ', 'QASDFGHJK, ASDFGHJKL, Ensenada Baja California', '5267890876', 'LICENCIA', 'DASFGHJ', '', '', '', '', '', '', '', '', '', 'ASDFG', 1, 0),
	(70, 'ferrefdv', 'wefdvcx, edfvcx, CP-43534, Ensenada Baja California', '4354534534', 'LICENCIA', 'DSFFEVD', '', '', '', '', 'wedfrefd', '4454433434', '', '', '', '', 1, 65),
	(71, 'DFDSFDSFSDF', 'SDFSDFDSFSD', '784521', 'DSFSDF', 'DSFSFDS', '', '', '', '', '', '', '', '', '', '', 0, 0),
	(72, 'DSFERGDFGDFGDFS', 'SDFSDFSDFDSFDS', '3423432423', 'SDFSDFSDFSDFSD', 'SDFSDFSDFSDFSD', '', '', '', '', '', '', '', '', '', '', 0, 0);

CREATE TABLE IF NOT EXISTS `contratos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_carro` int NOT NULL DEFAULT '0',
  `id_conductor` int NOT NULL DEFAULT '0',
  `precio_deposito` float NOT NULL DEFAULT '0',
  `precio_pagare` float NOT NULL DEFAULT '0',
  `precio_renta` float NOT NULL DEFAULT '0',
  `penalidad` float NOT NULL DEFAULT '0',
  `duracion` int NOT NULL DEFAULT '0',
  `fecha_inicio` datetime NOT NULL,
  `fecha_final` datetime NOT NULL,
  `contrato_doc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `deposito_doc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Contrato';


CREATE TABLE IF NOT EXISTS `propietarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `direccion` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nombreDocumento` varchar(50) DEFAULT NULL,
  `nroDocumento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Propietario de los vehiculos';

INSERT INTO `propietarios` (`id`, `nombre`, `direccion`, `telefono`, `nombreDocumento`, `nroDocumento`) VALUES
	(1, 'Carlos Zamir Flores Santillan', 'Blvd. Lazaro Cardenas 1536, Fracc. Playa Ensenada', '1111111111', 'INE', 'ASDFG43EYGUDHBC8'),
	(2, 'Jorge Ivan Perez Hernandez', 'Col. Todos Santos, C. ', '6461609694', 'LICENCIA DE CONDUCIR', 'EGFUYF87GIBJ3F');

CREATE TABLE IF NOT EXISTS `vehiculos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `marca` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `modelo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `color` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `anio` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `placas` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `placasDoc` varchar(200) DEFAULT '',
  `placasVencimiento` date DEFAULT NULL,
  `numeroSerie` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `imosPermiso` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `imosVencimiento` date DEFAULT NULL,
  `revisionMecanica` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `revisionMecanicaVencimiento` date DEFAULT NULL,
  `polizaSeguro` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `polizaSeguroVencimiento` date DEFAULT NULL,
  `tarjetaCirculacion` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `tarjetaCirculacionVencimiento` date DEFAULT NULL,
  `fotoCarro` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `precioRenta` int DEFAULT '0',
  `idPropietario` int DEFAULT '0',
  `idConductor` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='Vehivulos';

INSERT INTO `vehiculos` (`id`, `marca`, `modelo`, `color`, `anio`, `placas`, `placasDoc`, `placasVencimiento`, `numeroSerie`, `imosPermiso`, `imosVencimiento`, `revisionMecanica`, `revisionMecanicaVencimiento`, `polizaSeguro`, `polizaSeguroVencimiento`, `tarjetaCirculacion`, `tarjetaCirculacionVencimiento`, `fotoCarro`, `precioRenta`, `idPropietario`, `idConductor`) VALUES
	(62, 'Hyundai', 'Elantra', 'Gris', '2023', '87YUGH', '', '2024-03-10', '98UJNU879YUHJ8', '', '2024-03-10', '', '2024-03-10', '', '2024-03-10', '', '2024-03-10', '', 3200, 1, 58),
	(63, 'rgrgdfgdf', 'dfgdfgdfgdf', 'fdgdfgdfgdf', '2034', '34RFE43F34', '', '2024-06-06', '34TRFD34ERFD', 'https://drive.google.com/file/d/1iUcJ502q4m7HYRvzDu5P1n0eNEz-M66s/view?usp=drivesdk', '2024-07-06', 'https://drive.google.com/file/d/1wfNBH8IA0YR7ogcEqgH-EvMy_ohj7N0e/view?usp=drivesdk', '2024-08-06', '', '2024-09-06', '', '2024-10-06', 'https://drive.google.com/file/d/1cFmNAkZAfxaiPI4niEDEiA3XPPPaz8Pd/view?usp=drivesdk', 3453, 1, 60),
	(64, 'Nissan', 'Versa', 'Rojo', '2019', 'IUY87HUI98', '', '2024-05-10', '98UIE98UHIHIUY98', '', '2024-05-10', '', '2024-05-10', '', '2024-05-10', '', '2024-05-10', '', 3200, 1, 62),
	(65, 'Nissan', 'Versa', 'Gris', '2032', '87DF4', '', '2025-09-20', 'FH4UHU87HF48FUN', 'https://drive.google.com/file/d/1mIDuIVo2h2uCmd6pzZyIvshztjwUtIWV/view?usp=drivesdk', '2025-09-13', 'https://drive.google.com/file/d/1pK5wzpXdOMa2anKjZszTZKZpwcF3DSL9/view?usp=drivesdk', '2025-09-12', 'https://drive.google.com/file/d/1si19W7sR_fLIKR71fDgHi710SKVUceVZ/view?usp=drivesdk', '2025-09-02', 'https://drive.google.com/file/d/18VdHsolW3-aMA2eLtXyJoNvxVtuoyjWp/view?usp=drivesdk', '2025-10-01', 'https://drive.google.com/file/d/1dVOAtfT6a0nUsqxzTQxs_KPEWMXK9Xh-/view?usp=drivesdk', 3200, 2, 70),
	(66, 'tgfd', 'trefd', 'rf', '2010', '4GRVF', '', '2024-09-10', '4REF', '', '1970-01-01', '', '2024-09-10', '', '2024-09-10', '', '2024-09-10', '', 3434, 2, 0),
	(67, 'esdfgh', 'dsfg', 'edfgbn', '2034', 'SDFVB', '', '2024-10-20', 'DFGB', '', '2024-10-20', '', '2024-10-20', '', '2024-10-20', '', '2024-10-20', '', 3245, 1, 64),
	(68, 'Nissan ', 'March', 'Rojo', '2023', '45RTGBN', 'https://drive.google.com/file/d/1h-cm0LFC8-9vFtwFW-l8b-LyOELKn7_e/view?usp=drivesdk', '2025-07-10', '43RTHGTR54R5TGH', 'https://drive.google.com/file/d/1_mio6Kbtyu1t5UmQATtDUsFue1k_YTVC/view?usp=drivesdk', '2025-04-02', 'https://drive.google.com/file/d/1pt7cZXTxfc_2DMsSBd68EjgKlXRScIXm/view?usp=drivesdk', '2025-01-08', 'https://drive.google.com/file/d/1KVmplvRE28mdLobfODcG9BZ44q_wNt5z/view?usp=drivesdk', '2024-03-02', 'https://drive.google.com/file/d/1HSaKthx9B6h0YGqD0C6qtXbDk8MlNU2L/view?usp=drivesdk', '2024-05-02', 'https://drive.google.com/file/d/1GyA7lkAe2FfvHJQhi3xQwvLNTN_ssPKU/view?usp=drivesdk', 3000, 2, 67),
	(69, 'esrdfygh', 'werty', 'wertygh', '2032', 'SDFGHJ', '', '2024-10-21', 'ESRTYU', '', '2024-10-21', '', '2024-10-21', '', '2024-10-21', '', '2024-10-21', '', 2345, 1, 62),
	(70, 'xcvb', 'asdfg', 'asdfg', '2032', 'SDFGH', '', '2024-10-21', 'ASERDFGH', '', '2024-10-21', '', '2024-10-21', '', '2024-10-21', '', '2024-10-21', '', 2345, 1, 0),
	(71, 'asedrftg', 'asdfgh', 'qawedrftgh', '2023', 'ASDFGH', 'https://drive.google.com/file/d/1WyGGaoBK_-QsSxkvOeMJW-_rBVmCo3aa/view?usp=drivesdk', '2024-10-21', 'ASDFGH', 'https://drive.google.com/file/d/1YoE8fqgoaXQiYH4gy2UrnG3lYIbKY9Et/view?usp=drivesdk', '2024-10-21', 'https://drive.google.com/file/d/1vODLIlQrqCFQ8DfQQOwYupRVMDfNNSiQ/view?usp=drivesdk', '2024-10-21', 'https://drive.google.com/file/d/1GljnYibJPTwbaAHO77ZnADnBclStuJ4C/view?usp=drivesdk', '2024-10-21', 'https://drive.google.com/file/d/1-nKL5KlXZmjxgcY6BmtAc7xRFsEIP0fj/view?usp=drivesdk', '2024-10-21', 'https://drive.google.com/file/d/1E7miEM2YvBj99RU1qJF5mZSaSRHBmvNF/view?usp=drivesdk', 2345, 1, 64);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;

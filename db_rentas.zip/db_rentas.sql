/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `db_rentas` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_rentas`;

CREATE TABLE IF NOT EXISTS `cobros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idConductor` int DEFAULT '0',
  `idVehiculo` int DEFAULT '0',
  `idPropietario` int DEFAULT '0',
  `renta` float DEFAULT '0',
  `saldo` float DEFAULT '0',
  `cobro` float DEFAULT '0',
  `deuda` float DEFAULT '0',
  `pago` int DEFAULT '0',
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `nota` varchar(100) DEFAULT '.',
  `activo` int DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cobros de renta';

INSERT INTO `cobros` (`id`, `idConductor`, `idVehiculo`, `idPropietario`, `renta`, `saldo`, `cobro`, `deuda`, `pago`, `fechaInicio`, `fechaFin`, `nota`, `activo`) VALUES
	(21, 107, 98, 1, 0, 0, 0, 0, 0, NULL, NULL, '.', 1),
	(22, 107, 98, 1, 0, 0, 0, 0, 0, NULL, NULL, '', 1),
	(23, 107, 98, 1, 0, 0, 0, 0, 0, NULL, NULL, 'qqq', 1),
	(24, 107, 98, 1, 0, 0, 0, 0, 0, '2024-11-11', NULL, 'www', 1),
	(25, 107, 98, 1, 0, 0, 0, 0, 0, '2024-11-11', '2024-11-17', '', 1),
	(26, 107, 98, 1, 0, 0, 2998, 0, 0, '2024-11-11', '2024-11-17', 'DD', 1),
	(27, 107, 98, 1, 3000, 12, 2988, 0, 0, '2024-11-11', '2024-11-17', 'ffff', 1),
	(28, 107, 98, 1, 3250, 1230.62, 2019.38, 0, 0, '2024-11-11', '2024-11-17', 'll', 1),
	(29, 107, 98, 1, 3250, -1230.62, 4480.62, 0, 0, '2024-11-11', '2024-11-17', 'll', 1),
	(30, 107, 98, 1, 3000, 1250.6, 1749.4, 0, 0, '2024-11-11', '2024-11-17', 'AAA', 1),
	(31, 107, 98, 1, 3000, 1, 2999, 0, 0, '2024-11-11', '2024-11-17', 'A', 1),
	(32, 107, 98, 1, 3000, 1, 2999, 0, 0, '2024-11-11', '2024-11-17', 'a', 1),
	(33, 107, 98, 1, 3000, 1, 2999, 0, 0, '2024-11-11', '2024-11-17', 'a', 1),
	(34, 107, 98, 1, 3000, 1, 2999, 0, 0, '2024-11-11', '2024-11-17', 'a', 1),
	(35, 108, 99, 1, 3000, 2, 2998, 0, 0, '2024-11-11', '2024-11-17', 'b', 1),
	(36, 106, 97, 2, 4250, 3, 4247, 0, 0, '2024-11-11', '2024-11-17', 'c', 1);

CREATE TABLE IF NOT EXISTS `conductores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `direccion` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `telefono` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `nombreDocumento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `nroDocumento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `ineDoc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `licenciaDoc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `reciboLuz` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `reciboAgua` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalNombre` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalTelefono` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalDoc` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalLuz` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `avalAgua` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `nota` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `activo` int DEFAULT '0',
  `idVehiculo` int DEFAULT '0',
  `idContrato` int DEFAULT '0',
  `idDeposito` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Conductores';

INSERT INTO `conductores` (`id`, `nombre`, `direccion`, `telefono`, `nombreDocumento`, `nroDocumento`, `ineDoc`, `licenciaDoc`, `reciboLuz`, `reciboAgua`, `avalNombre`, `avalTelefono`, `avalDoc`, `avalLuz`, `avalAgua`, `nota`, `activo`, `idVehiculo`, `idContrato`, `idDeposito`) VALUES
	(106, 'Jose Rodrigo Arechiga Gamboa', 'Todos Santos, San Carlos, #137, CP-22785, Ensenada Baja California', '3456754324', 'LICENCIA', '87JFEHBBJ89', 'https://drive.google.com/file/d/1nZif8ZxgC8e2OcFZuohgClRSLG5o7V2N/view?usp=drivesdk', 'https://drive.google.com/file/d/1Cj3DuSk1mNHS7Bc-SzpQVDQNwbT7_wp_/view?usp=drivesdk', 'https://drive.google.com/file/d/1pQr2MFFetXOCVhqDmbG9RNsTLFmALMaZ/view?usp=drivesdk', 'https://drive.google.com/file/d/1BBvrKd25nISh2aIbnpdpGMX9qVyoEP1y/view?usp=drivesdk', 'Manuel Torres felix', '6485722526', 'https://drive.google.com/file/d/1phwVvvL2JFYesRfuVQyHnfNKxhnEL0fX/view?usp=drivesdk', 'https://drive.google.com/file/d/1RB8D-fYF9F8uT9sKxkNFlthpmUBi2Jrg/view?usp=drivesdk', 'https://drive.google.com/file/d/16s20iP0mAyxejSPpMdX2Qqj08sFWSpeq/view?usp=drivesdk', 'Casa Dos Pisos', 1, 97, 164, 0),
	(107, 'Felipe Ferras Gomez', 'Colinas del Mar, Coral, #118, INT-7, CP-55785, Ensenada Baja California', '3245675434', 'INE', 'ASDFG43EYGUDHBC8', 'https://drive.google.com/file/d/1B2OsYwjmEXhGmGhccSZxUL-AyFwx8kxZ/view?usp=drivesdk', 'https://drive.google.com/file/d/116QnX1XYFl4sCk7evsend7hPu7qxkzUW/view?usp=drivesdk', 'https://drive.google.com/file/d/15qn_XtGi55SO3q3youpEO-bJr_yH0nwt/view?usp=drivesdk', 'https://drive.google.com/file/d/16tuSDFgancn4D3I6mDSpmnjNdt5IzboB/view?usp=drivesdk', 'Joaquin Guzman Loera', '6485722526', 'https://drive.google.com/file/d/1j1Uk3B_75Caz_favWkb_nbhsdYyBU0yh/view?usp=drivesdk', '', '', 'Casa Dos Pisos', 1, 98, 165, 0),
	(108, 'Vicente Zambada Niebla', 'Fracc.Coral, C.Mar, #2009, CP-22819, Ensenada Baja California', '5653120467', 'INE', 'ADJJMMRRA200023', 'https://drive.google.com/file/d/1g95ygdSZ7KkFA5cReb4GRHSIOjIGz0Ti/view?usp=drivesdk', 'https://drive.google.com/file/d/11-zEqgCvA8s_2umFMSBrNhTNnzA2t27h/view?usp=drivesdk', '', 'https://drive.google.com/file/d/19wg0fL63505fJzy8O8Q7anxjj1n0d3UC/view?usp=drivesdk', '', '', '', '', '', 'Hola me llamo jefft', 1, 99, 166, 0),
	(109, 'Anabel Hernandez', 'Colinas del Mar, San Carlos, MZ-56, CP-23456, Ensenada Baja California', '6598555455', 'LICENCIA', 'ASDFG43EYGUDHBC8', '', '', '', '', '', '', '', '', '', '', 1, 100, 0, 0);

CREATE TABLE IF NOT EXISTS `contratos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `precioDeposito` float NOT NULL DEFAULT '0',
  `precioRenta` float NOT NULL DEFAULT '0',
  `precioPagare` float NOT NULL DEFAULT '0',
  `penalidad` float NOT NULL DEFAULT '0',
  `duracionMeses` int NOT NULL DEFAULT '0',
  `fechaFirma` date NOT NULL,
  `fechaInicio` date NOT NULL,
  `fechaFin` date NOT NULL,
  `contratoDoc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `depositoDoc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `idConductor` int NOT NULL DEFAULT '0',
  `idVehiculo` int NOT NULL DEFAULT '0',
  `idPropietario` int DEFAULT '0',
  `estado` int DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Contrato';

INSERT INTO `contratos` (`id`, `precioDeposito`, `precioRenta`, `precioPagare`, `penalidad`, `duracionMeses`, `fechaFirma`, `fechaInicio`, `fechaFin`, `contratoDoc`, `depositoDoc`, `idConductor`, `idVehiculo`, `idPropietario`, `estado`) VALUES
	(163, 3000, 3000, 10000, 75, 2, '2024-11-05', '2024-11-05', '2025-01-05', 'https://drive.google.com/file/d/1ZkuoFC84PWHjVQTL778h5NI0ULs369vQ/view?usp=drivesdk', 'https://drive.google.com/file/d/1CrokVl1BBOVLsRMojH6BVtglsPbWg6yT/view?usp=drivesdk', 106, 97, 1, 0),
	(164, 3000, 4250, 10000, 75, 2, '2024-11-05', '2024-11-05', '2025-01-05', 'https://drive.google.com/file/d/1Oemt35j08b7c8WjSzP9-nB937nVwBLAG/view?usp=drivesdk', 'https://drive.google.com/file/d/1GgjVFIziFHLQVFXS8YjgqDO7e4WtaOrN/view?usp=drivesdk', 106, 98, 2, 1),
	(165, 3000, 3000, 10000, 75, 2, '2024-11-10', '2024-11-10', '2025-01-10', 'https://drive.google.com/file/d/1OaEYXc7N2lX_zD_f1u6n-9IOG8yjskhR/view?usp=drivesdk', 'https://drive.google.com/file/d/11pd_D6H8lYWQtwIEUFUhle_fB1tskuRM/view?usp=drivesdk', 107, 97, 1, 1),
	(166, 3000, 3000, 10000, 75, 2, '2024-11-11', '2024-11-11', '2025-01-11', 'https://drive.google.com/file/d/1YaZbYaQrx7hEGKyC-VugUsWYVwlFNqMh/view?usp=drivesdk', 'https://drive.google.com/file/d/1zCdGOZQaOsu3k-oO2vgooAl2MwKexBYw/view?usp=drivesdk', 108, 99, 1, 1);

CREATE TABLE IF NOT EXISTS `propietarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `direccion` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `telefono` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nombreDocumento` varchar(50) DEFAULT NULL,
  `nroDocumento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Propietario de los vehiculos';

INSERT INTO `propietarios` (`id`, `nombre`, `direccion`, `telefono`, `nombreDocumento`, `nroDocumento`) VALUES
	(1, 'Carlos Zamir Flores Santillan', 'Blvd. Lazaro Cardenas 1536, Fracc. Playa Ensenada', '1111111111', 'INE', 'ASDFG43EYGUDHBC8'),
	(2, 'Jorge Ivan Perez Hernandez', 'Col. Todos Santos, C. ', '6461609694', 'LICENCIA DE CONDUCIR', 'EGFUYF87GIBJ3F');

CREATE TABLE IF NOT EXISTS `vehiculos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `marca` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `modelo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `color` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `anio` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `placas` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `placasDoc` varchar(200) DEFAULT '',
  `placasVencimiento` date DEFAULT NULL,
  `numeroSerie` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `imosPermiso` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `imosVencimiento` date DEFAULT NULL,
  `revisionMecanica` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `revisionMecanicaVencimiento` date DEFAULT NULL,
  `polizaSeguro` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `polizaSeguroVencimiento` date DEFAULT NULL,
  `tarjetaCirculacion` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `tarjetaCirculacionVencimiento` date DEFAULT NULL,
  `fotoCarro` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `precioRenta` int DEFAULT '0',
  `idPropietario` int DEFAULT '0',
  `idConductor` int DEFAULT '0',
  `activo` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='Vehivulos';

INSERT INTO `vehiculos` (`id`, `marca`, `modelo`, `color`, `anio`, `placas`, `placasDoc`, `placasVencimiento`, `numeroSerie`, `imosPermiso`, `imosVencimiento`, `revisionMecanica`, `revisionMecanicaVencimiento`, `polizaSeguro`, `polizaSeguroVencimiento`, `tarjetaCirculacion`, `tarjetaCirculacionVencimiento`, `fotoCarro`, `precioRenta`, `idPropietario`, `idConductor`, `activo`) VALUES
	(97, 'Nissan', 'Versa', 'Rojo', '2019', '78YUGHBJ', 'https://drive.google.com/file/d/12MDYHOuvGcFvQK9nb2fg2yireftqhxhy/view?usp=drivesdk', '2025-10-03', '54TYGRF45GREFRDD', 'https://drive.google.com/file/d/135mqLlvvCwmCkQqTjeozDyw0WRBeSJZF/view?usp=drivesdk', '2025-10-02', 'https://drive.google.com/file/d/1fqzoX5VKPsOrYAqRGLN2o12dNq1YmfCK/view?usp=drivesdk', '2025-10-01', 'https://drive.google.com/file/d/1MSXTLoIKhBlCFj3xBfkutSQZkl_hVS--/view?usp=drivesdk', '2025-10-01', 'https://drive.google.com/file/d/1cMBTMNN1PiE5JRyBakHPxYlNKDaUt3oB/view?usp=drivesdk', '2025-10-10', 'https://drive.google.com/file/d/1r_GuTdCacYwgQYcnIkWOY3YBHm-NqNgM/view?usp=drivesdk', 3200, 1, 106, 1),
	(98, 'Chevrolet', 'Aveo', 'Gris', '2018', 'DFR45T', 'https://drive.google.com/file/d/1wAgWgHFGFxD1Jfb6gXEsmx9LTkcgFDIL/view?usp=drivesdk', '2024-10-02', '45TRGFD54REF4RF', 'https://drive.google.com/file/d/1uC7nttXWl56lTEF8FxBCc1Ysgdj0ROra/view?usp=drivesdk', '2024-11-15', 'https://drive.google.com/file/d/1Oiv6v3OGAuZZQEf1YSxqo0YsCJwS_ar1/view?usp=drivesdk', '2024-12-13', 'https://drive.google.com/file/d/1h1APbJHat5BEgRxWA7mVmBdMvDCYb2u3/view?usp=drivesdk', '2024-12-11', 'https://drive.google.com/file/d/1U49cBJ9Cs6DcwJjrm0IbHQNe0L47Ueho/view?usp=drivesdk', '2025-10-03', 'https://drive.google.com/file/d/1D6EdHtWHiSol5lq9U0QtWxDj77ppRF85/view?usp=drivesdk', 3100, 2, 107, 1),
	(99, 'Renault', 'Kwid', 'Azul Marino', '2022', '45RTFVGTR', 'https://drive.google.com/file/d/1LKjJqipbMdm3jqJQYkPNCkVqueUN_NJt/view?usp=drivesdk', '2025-10-10', '54TRGFDGTR', 'https://drive.google.com/file/d/1xPmAnBgY5AnGrA6-t4ZZI0j8qX93UMC3/view?usp=drivesdk', '2025-10-10', 'https://drive.google.com/file/d/16LNEKXW50Sw50EwIQWu-Y4eIPyJFiK21/view?usp=drivesdk', '2025-10-09', 'https://drive.google.com/file/d/1rewdLwQmrFpeFMrFHv0k-BRnETUHZuba/view?usp=drivesdk', '2025-10-02', 'https://drive.google.com/file/d/1iiPJrczo-oyQO-zY-XTYilKjiPVcbADw/view?usp=drivesdk', '2025-10-09', 'https://drive.google.com/file/d/1NGKVjAgG-7VwYR8PpUyjElwFzEAsEZF5/view?usp=drivesdk', 3200, 2, 108, 1),
	(100, 'Renault', 'Kwid', 'Azul Marino', '2022', '45RTFVGTR', 'https://drive.google.com/file/d/1wygMyoO-n1LJ8DxUCsxXBYZvgZbldnsm/view?usp=drivesdk', '2025-10-10', '54TRGFDGTR', 'https://drive.google.com/file/d/1nsHtJAVI2uLREuAcm0pGaFGIgsZ4TObT/view?usp=drivesdk', '2025-10-10', 'https://drive.google.com/file/d/1QJWT6khIqC_Po0p6YlbtB_mWY6xrJMmS/view?usp=drivesdk', '2025-10-09', 'https://drive.google.com/file/d/11EF1SBdE65ZvHIOmVf1BHAXkhnn25A24/view?usp=drivesdk', '2025-10-02', 'https://drive.google.com/file/d/1V5196YhBceKAIhg03pUKBXK3Ny04gi4s/view?usp=drivesdk', '2025-10-09', 'https://drive.google.com/file/d/1vOPWk1MITupKY0HQo_Z_5WBrhbYKIdtL/view?usp=drivesdk', 3200, 2, 109, 0);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
